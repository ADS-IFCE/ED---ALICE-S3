import random

def iniciar_grade(n_linhas, n_colunas, inicial=None):
    return ((inicial, ) * n_colunas, ) * n_linhas

def n_colunas(grade):
    return len(grade[0])

def n_linhas(grade):
    return len(grade)

def preencher(grade, valor):
    return iniciar_grade(n_linhas(grade), n_colunas(grade), valor)

def tamanho(grade):
    return n_linhas(grade) * n_colunas(grade)

def print2D(grade):
    print()
    for linha in grade:
        print(linha)
    print()

def esta_vazia(grade):
    for linha in grade:
        for elemento in linha:
            if elemento != None:
                return False
    
    return True

def indice_valido(grade, linha, coluna):
    if linha < 0 or coluna < 0:
        return False
    
    if linha > n_linhas(grade) or coluna > n_colunas(grade):
        return False
    
    return True

def acessar(grade, linha, coluna):
    if indice_valido(grade, linha, coluna):
        return grade[linha][coluna]
    return None


def alterar(grade, linha, coluna, valor):
    if indice_valido(grade, linha, coluna):
        pos = (linha, coluna)
        
        grade = tuple(
            tuple(
                valor if pos == (i, j) else acessar(grade, i, j)
                for j in range(n_colunas(grade))
            )
            for i in range(n_linhas(grade))
        )

    return grade

g = iniciar_grade(3,3)

g = alterar(g, 2, 1, 'Saulo')
print2D(g)

g = alterar(g, 0, 0, 'João')
print2D(g)

g = alterar(g, 0, 2, 'Alice')
print2D(g)